@extends('admin.layouts.template')
@section('page_title')
Dashboard - Single Ecom
@endsection
@section('content')
Hello fromd dashboard
@endsection