@extends('usertemplate.layouts.template')
@section('main-content')
<h2>New release</h2>
@endsection