@extends('usertemplate.layouts.template')
@section('main-content')
<h2>Today deleal</h2>
@endsection